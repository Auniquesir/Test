# 自动化Loon插件转换仓库

> [!CAUTION]
> 禁止在中华人民共和国境内平台公开传播本仓库内的任何内容或以此牟利！

> [!IMPORTANT]
> 本仓库为灾备仓库，不保证插件自身功能，敬请仅参考实现方式。

> [!IMPORTANT]
> 转载时你需要保留[插件源仓库](https://github.com/luestr/ProxyResource)署名信息，且遵守[插件源仓库](https://github.com/luestr/ProxyResource)的 [CC BY-NC-SA 4.0](https://github.com/luestr/ProxyResource/blob/main/LICENSE.md) 许可协议。


### 仓库功能

1. 灾备
2. 将Loon插件转换为Surge插件

### 特别鸣谢

[QingRex](https://github.com/QingRex)

[可莉](https://github.com/luestr/ProxyResource)

[ScriptHub](https://github.com/Script-Hub-Org/Script-Hub)

[小一](https://github.com/xream)
